package com.example.fountainandgo.SCREENS;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.fountainandgo.R;

public class WenasScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wenas_screen);
    }
}
package com.example.fountainandgo.SCREENS;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.fountainandgo.R;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

public class MapaScreen extends AppCompatActivity
        implements OnMyLocationButtonClickListener,
        OnMyLocationClickListener,
        OnMapReadyCallback,
        ActivityCompat.OnRequestPermissionsResultCallback {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private boolean permissionDenied = false;
    private GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa_screen);
        //CARGAR EL MAPA
        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;
        map.setOnMyLocationButtonClickListener(this);
        map.setOnMyLocationClickListener(this);
        enableMyLocation();
    }

    @SuppressLint("MissingPermission")
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            map.setMyLocationEnabled(true);
            return;
        }

        requestLocationPermissions(this, LOCATION_PERMISSION_REQUEST_CODE);
    }

    @Override
    public boolean onMyLocationButtonClick() {
        Toast.makeText(this, "MyLocation button clicked", Toast.LENGTH_SHORT).show();
        return false;
    }
    //MENSAJE CUANDO SE PULSA SU POSICION EN EL MAPA

    @Override
    public void onMyLocationClick(@NonNull Location location) {
        //SE MOSTRARÁ EL SIGUIENTE MENSAJE CUANDO EL USUARIO HAYA PULSADO SU UBUCACIÓN ACTUAL

        Toast.makeText(this, "Current location:\n" + location, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            //SI LOS PERMISOS HAN SIDO CONCEDIDOS TENDRÁ EL USUARIO ACCESO Y SE LE HABILITARÁ SU LOCALIZACIÓN

            if (isPermissionGranted(permissions, grantResults, Manifest.permission.ACCESS_FINE_LOCATION) ||
                    isPermissionGranted(permissions, grantResults, Manifest.permission.ACCESS_COARSE_LOCATION)) {
                enableMyLocation();
            } else {
                permissionDenied = true;
            }
        }
    }

    @Override
    protected void onResumeFragments() {
        //VERIFICA SI LOS PERMISOS SE HAN CONDECIDO EN EL CASO DE QUE NO SE HAYAN CONCEDIDO LOS PERMISOS SE MOSTRARÁ EL MENSAJE
        // QUE GENERARÁ showMissingPermissionError
        super.onResumeFragments();
        if (permissionDenied) {
            showMissingPermissionError();
            permissionDenied = false;
        }
    }

    private void showMissingPermissionError() {
        // Muestra un mensaje de error al usuario
        Toast.makeText(this, "FALTAN LOS PERMISOS PORFAVOR CONCEDA LOS PERMISOS", Toast.LENGTH_SHORT).show();

    }

    public static void requestLocationPermissions(Activity activity, int requestCode) {
        //ENVIAR LA SOLICITUD PARA PEDIR AL USUARIO LOS PERMISOS DE LOCALIZACIÓN
        //SE MOSTRARÁ LA INTERFAZ QUE TE PEDIRÁ LOS PERMISOS DE UBICACIÓN
       ActivityCompat.requestPermissions(activity,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                requestCode);
    }

    public static boolean isPermissionGranted(String[] permissions, int[] grantResults, String permission) {
        //RECIBE LOS PERMISOS Y COMPRUEBA SI ESTÁN GARANTIZADOS
        for (int i = 0; i < permissions.length; i++) {
            if (permission.equals(permissions[i])) {
                return grantResults[i] == PackageManager.PERMISSION_GRANTED;
            }
        }
        return false;
    }
}
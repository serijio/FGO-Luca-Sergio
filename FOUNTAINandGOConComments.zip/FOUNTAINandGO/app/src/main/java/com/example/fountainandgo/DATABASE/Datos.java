package com.example.fountainandgo.DATABASE;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class Datos extends SQLiteOpenHelper {

    private static final String DB_NAME = "Fountain&GO";
    private static final int DB_VERSION = 1;

    public Datos(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users " +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre VARCHAR(25) NOT NULL," +
                "apellidos VARCHAR(25) NOT NULL," +
                "usuario VARCHAR(25) NOT NULL," +
                "contrasena VARCHAR(25) NOT NULL," +
                "confcontrasena VARCHAR(25) NOT NULL," +
                "email VARCHAR(25) NOT NULL)");

        db.execSQL("CREATE TABLE fuentes " +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "latitud DOUBLE NOT NULL," +
                "longitud DOUBLE NOT NULL, " +
                "nombre VARCHAR(25) NOT NULL, " +
                "direccion VARCHAR(50) NOT NULL, " +
                "codigopostal DOUBLE NOT NULL, " +
                "provincia VARCHAR(25) NOT NULL)");

        db.execSQL("CREATE TABLE suggestions " +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombreSug VARCHAR(25) NOT NULL," +
                "direccionSug VARCHAR(25) NOT NULL," +
                "cpSug VARCHAR(25) NOT NULL," +
                "provinciaSug VARCHAR(25) NOT NULL," +
                "textoSug TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public class Fuente {
        private int id;
        private double latitud;
        private double longitud;
        private String nombre;
        private String direccion;
        private double codigoPostal;
        private String provincia;

        public Fuente (int id, double latitud, double longitud, String nombre, String direccion, double codigoPostal, String provincia) {
            this.id = id;
            this.latitud = latitud;
            this.longitud = longitud;
            this.nombre = nombre;
            this.direccion = direccion;
            this.codigoPostal = codigoPostal;
            this.provincia = provincia;
        }

        public int getId() {
            return id;
        }
        public void setId(int id) {
            this.id = id;
        }

        public double getLatitud() {
            return latitud;
        }
        public void setLatitud(double latitud) {
            this.latitud = latitud;
        }

        public double getLongitud() {
            return longitud;
        }
        public void setLongitud(double longitud) {
            this.longitud = longitud;
        }

        public String getNombre() {
            return nombre;
        }
        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getDireccion() {
            return direccion;
        }
        public void setDireccion(String direccion) {
            this.direccion = direccion;
        }

        public double getCodigoPostal() {
            return codigoPostal;
        }
        public void setCodigoPostal(double codigoPostal) {
            this.codigoPostal = codigoPostal;
        }

        public String getProvincia() {
            return provincia;
        }
        public void setProvincia(String provincia) {
            this.provincia = provincia;
        }
    }

    public class Suggestion {
        private int id;
        private String nombreSug;
        private String direccionSug;
        private double cpSug;
        private String provinciaSug;
        private String textoSug;

        public Suggestion(int id, String nombreSug, String direccionSug, double cpSug, String provinciaSug, String textoSug) {
            this.id = id;
            this.nombreSug = nombreSug;
            this.direccionSug = direccionSug;
            this.cpSug = cpSug;
            this.provinciaSug = provinciaSug;
            this.textoSug = textoSug;
        }

        public int getId() {
            return id;
        }
        public void setId(int id) {
            this.id = id;
        }

        public String getNombreSug() {
            return nombreSug;
        }
        public void setNombreSug(String nombreSug) {
            this.nombreSug = nombreSug;
        }

        public String getDireccionSug() {
            return direccionSug;
        }
        public void setDireccionSug(String direccionSug) {
            this.direccionSug = direccionSug;
        }

        public double getCpSug() {
            return cpSug;
        }
        public void setCpSug(double cpSug) {
            this.cpSug = cpSug;
        }

        public String getProvinciaSug() {
            return provinciaSug;
        }
        public void setProvinciaSug(String provinciaSug) {
            this.provinciaSug = provinciaSug;
        }

        public String getTextoSug() {
            return textoSug;
        }
        public void setTextoSug(String textoSug) {
            this.textoSug = textoSug;
        }

        public String toPrintSug() {
            return "ID: " + id + "\nNombre de la fuente: " + nombreSug + "\nDirección de la fuente: "
                    + direccionSug + "\nCódigo Postal: " + cpSug + "\nProvincia/Localidad de la fuente"
                    + provinciaSug + "\nComentarios adicionales: " + textoSug;
        }
    }

    public ArrayList<Fuente> obtenerFuentes() {
        ArrayList<Fuente> listaFuentes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM fuentes", null);

        int columnIndexId = cursor.getColumnIndex("id");
        int columnIndexLatitud = cursor.getColumnIndex("latitud");
        int columnIndexLongitud = cursor.getColumnIndex("longitud");
        int columnIndexNombre = cursor.getColumnIndex("nombre");
        int columnIndexDireccion = cursor.getColumnIndex("direccion");
        int columnIndexCodigoPostal = cursor.getColumnIndex("codigopostal");
        int columnIndexProvincia = cursor.getColumnIndex("provincia");

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(columnIndexId);
                double latitud = cursor.getDouble(columnIndexLatitud);
                double longitud = cursor.getDouble(columnIndexLongitud);
                String nombre = cursor.getString(columnIndexNombre);
                String direccion = cursor.getString(columnIndexDireccion);
                double codigoPostal = cursor.getDouble(columnIndexCodigoPostal);
                String provincia = cursor.getString(columnIndexProvincia);

                Fuente fuente = new Fuente(id, latitud, longitud, nombre, direccion, codigoPostal, provincia);
                listaFuentes.add(fuente);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return listaFuentes;
    }

    public ArrayList<Suggestion> obtenerSuggestions(Context context) {
        ArrayList<Suggestion> listaSuggestions = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM suggestions", null);

        int columnIndexId = cursor.getColumnIndex("id");
        int columnIndexNombreSug = cursor.getColumnIndex("nombresug");
        int columnIndexDireccionSug = cursor.getColumnIndex("direccionSug");
        int columnIndexCpSug = cursor.getColumnIndex("cpSug");
        int columnIndexProvinciaSug = cursor.getColumnIndex("provinciaSug");
        int columnIndexTextoSug = cursor.getColumnIndex("textoSug");

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(columnIndexId);
                String nombreSug = cursor.getString(columnIndexNombreSug);
                String direccionSug = cursor.getString(columnIndexDireccionSug);
                double cpSug = cursor.getDouble(columnIndexCpSug);
                String provinciaSug = cursor.getString(columnIndexProvinciaSug);
                String textoSug = cursor.getString(columnIndexTextoSug);

                Suggestion suggestion = new Suggestion(id, nombreSug, direccionSug, cpSug, provinciaSug, textoSug);
                listaSuggestions.add(suggestion);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return listaSuggestions;
    }

    public Fuente getFuenteFromDatabase(int idFuente) {
        SQLiteDatabase db = this.getReadableDatabase();
        Fuente fuente = null;

        Cursor cursor = db.query(
                "fuentes",
                null,
                "id = ?",
                new String[]{String.valueOf(idFuente)},
                null,
                null,
                null
        );

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int columnIndexId = cursor.getColumnIndex("id");
                int columnIndexLatitud = cursor.getColumnIndex("latitud");
                int columnIndexLongitud = cursor.getColumnIndex("longitud");
                int columnIndexNombre = cursor.getColumnIndex("nombre");
                int columnIndexDireccion = cursor.getColumnIndex("direccion");
                int columnIndexCodigoPostal = cursor.getColumnIndex("codigopostal");
                int columnIndexProvincia = cursor.getColumnIndex("provincia");

                int id = cursor.getInt(columnIndexId);
                double latitud = cursor.getDouble(columnIndexLatitud);
                double longitud = cursor.getDouble(columnIndexLongitud);
                String nombre = cursor.getString(columnIndexNombre);
                String direccion = cursor.getString(columnIndexDireccion);
                double codigoPostal = cursor.getDouble(columnIndexCodigoPostal);
                String provincia = cursor.getString(columnIndexProvincia);

                fuente = new Fuente(id, latitud, longitud, nombre, direccion, codigoPostal, provincia);
            }
            cursor.close();
        }

        if (fuente == null) {
            Log.d("BottomSheetFragment", "La fuente obtenida de la base de datos es nula");
        } else {
            Log.d("BottomSheetFragment", "Fuente encontrada en la base de datos: " + fuente.toString());
        }

        return fuente;
    }

    public boolean esIdFuenteValido(int idFuente) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM fuentes WHERE id = ?", new String[]{String.valueOf(idFuente)});
        boolean existeId = cursor != null && cursor.moveToFirst();

        if (cursor != null) {
            cursor.close();
        }

        return existeId;
    }

}
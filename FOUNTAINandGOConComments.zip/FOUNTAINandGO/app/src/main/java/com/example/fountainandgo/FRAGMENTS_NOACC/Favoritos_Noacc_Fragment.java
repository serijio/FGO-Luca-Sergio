package com.example.fountainandgo.FRAGMENTS_NOACC;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.fountainandgo.DATABASE.Fuentes;
import com.example.fountainandgo.R;

public class Favoritos_Noacc_Fragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;

    // Constructor vacío necesario para instanciar el fragmento
    public Favoritos_Noacc_Fragment() {}

    // Método estático para crear una nueva instancia del fragmento con argumentos
    public static Favoritos_Noacc_Fragment newInstance(String param1, String param2) {
        Favoritos_Noacc_Fragment fragment = new Favoritos_Noacc_Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    // Método llamado cuando se crea el fragmento
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    // Método para mostrar elementos en la vista
    public void showElements(View view) {
        // Obtener una instancia de la base de datos en modo lectura
        SQLiteDatabase dbf = new Fuentes(view.getContext()).getReadableDatabase();

        // Asignar el resultado de findViewById a una variable
        LinearLayout fillContentShow = view.findViewById(R.id.fillContentShow);

        // Realizar una consulta a la base de datos para obtener las fuentes
        Cursor fuentes = dbf.rawQuery("SELECT * FROM Fuentes", null);

        // Verificar si hay al menos una fuente en la base de datos
        if (fuentes.moveToFirst()) {
            // Crear un StringBuilder para almacenar la información de las fuentes
            StringBuilder dataText = new StringBuilder();
            do {
                // Obtener datos de la fuente actual en el cursor
                int id = fuentes.getInt(0);
                String Latitud = fuentes.getString(1);
                String Longitud = fuentes.getString(2);
                String NombreFuente = fuentes.getString(3);
                String DirFuente = fuentes.getString(4);
                String cpFuente = fuentes.getString(5);
                String ciudadFuente = fuentes.getString(6);

                // Agregar información al StringBuilder
                dataText.append("Latitud: ").append(Latitud).append("\n")
                        .append("Longitud: ").append(Longitud).append("\n")
                        .append("Nombre Fuente:").append(NombreFuente).append("\n")
                        .append("Dirección : ").append(DirFuente).append("\n")
                        .append("Codigo Postal: ").append(cpFuente).append("\n")
                        .append("Ciudad: ").append(ciudadFuente).append("\n");

            } while (fuentes.moveToNext());

            // Obtener la referencia al TextView en la vista y establecer el texto
            TextView dataTextView_nacc_fav = view.findViewById(R.id.dataTextView_nacc_fav);
            dataTextView_nacc_fav.setText(dataText.toString());

            // Hacer algo con fillContentShow si es necesario
            // fillContentShow.setVisibility(View.VISIBLE); por ejemplo
        }
    }

    // Método llamado cuando se crea la vista del fragmento
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflar el diseño de la vista del fragmento
        View view = inflater.inflate(R.layout.fragment_favoritos_noacc, container, false);

        // Obtener referencia al botón en la vista y configurar el evento de clic
        Button showButton = view.findViewById(R.id.showbutton);
        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llamar al método para mostrar elementos cuando se hace clic en el botón
                showElements(view);
            }
        });

        // Devolver la vista inflada
        return view;
    }
}
